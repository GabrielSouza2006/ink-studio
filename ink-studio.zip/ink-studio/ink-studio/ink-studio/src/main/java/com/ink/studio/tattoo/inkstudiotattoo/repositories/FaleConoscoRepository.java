package com.ink.studio.tattoo.inkstudiotattoo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ink.studio.tattoo.inkstudiotattoo.model.FaleConosco;

public interface FaleConoscoRepository extends JpaRepository<FaleConosco, Long>{

}
